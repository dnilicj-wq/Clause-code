=== AAS Landing Assets ===
Stable tag: 1.0.0
Requires at least: 6.2
Requires PHP: 7.4
License: GPLv2 or later

Styles, scripts and fonts for the AAS Group outdoor landing page (Elementor). Loads only on that page.
